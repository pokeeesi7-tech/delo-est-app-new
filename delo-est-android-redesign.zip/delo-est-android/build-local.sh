#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

BUILD_NUMBER="${BUILD_NUMBER:-2026101601}"
if [[ ! "$BUILD_NUMBER" =~ ^[1-9][0-9]*$ ]] || (( BUILD_NUMBER > 2100000000 )); then
  echo "BUILD_NUMBER должен быть целым числом от 1 до 2100000000." >&2
  exit 1
fi

command -v flutter >/dev/null 2>&1 || { echo "Flutter SDK не найден в PATH." >&2; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "Python 3 не найден в PATH." >&2; exit 1; }

printf '1/6 Создаю локальный Android-каркас Flutter...\n'
rm -rf shell
flutter create --org ru.deloest --project-name delo_est --platforms android --no-pub shell

printf '2/6 Копирую исходники и ресурсы...\n'
rm -rf shell/lib
mkdir -p shell/lib shell/assets
cp ./*.dart shell/lib/
cp pubspec.yaml shell/
for name in icon.png icon_fg.png icon_orange.png icon_purple.png; do
  test -f "$name" || { echo "Не найден файл $name" >&2; exit 1; }
  cp "$name" "shell/assets/$name"
done

printf '3/6 Устанавливаю зависимости и создаю иконки...\n'
(
  cd shell
  flutter pub get
  dart run flutter_launcher_icons
  printf '4/6 Настраиваю Android-манифест и переключение иконки...\n'
  python3 ../configure_android.py
)

printf '5/6 Подготавливаю ключ подписи приложения...\n'
mkdir -p "$HOME/.android"
if [ -f "$HOME/.android/debug.keystore" ]; then
  cp "$HOME/.android/debug.keystore" "$HOME/.android/debug.keystore.backup-$(date +%Y%m%d-%H%M%S)"
fi
cp debug.keystore "$HOME/.android/debug.keystore"

printf '6/6 Собираю APK...\n'
(
  cd shell
  flutter build apk --release --build-name=1.0.0 --build-number="$BUILD_NUMBER"
)
cp shell/build/app/outputs/flutter-apk/app-release.apk DeloEst.apk
printf '\nГотово: %s/DeloEst.apk\n' "$PWD"
