import 'package:flutter/material.dart';
import 'ad_page.dart';
import 'auth.dart';
import 'models.dart';
import 'state.dart';
import 'theme.dart';
import 'util.dart';
import 'widgets.dart';

/// Избранное — единое место для сохранённых объявлений и поисков.
/// Состояние самих избранных сущностей по-прежнему хранится в S и не зависит от UI.
class FavoritesPage extends StatefulWidget {
  const FavoritesPage({super.key});

  @override
  State<FavoritesPage> createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {
  int _section = 0;
  final TextEditingController _query = TextEditingController();
  String _sort = 'new';

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  List<Ad> _filteredAds() {
    final q = _query.text.trim().toLowerCase();
    final ads = S.i.ads.where((a) => S.i.isFav(a.id)).where((a) {
      if (q.isEmpty) return true;
      return '${a.title} ${a.desc} ${a.city} ${a.category} ${a.type}'.toLowerCase().contains(q);
    }).toList();
    ads.sort((a, b) => _sort == 'old' ? a.ts.compareTo(b.ts) : b.ts.compareTo(a.ts));
    return ads;
  }

  Future<void> _clearFavorites() async {
    final count = S.i.fav.length;
    if (count == 0) return;
    final p = pal(context);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        icon: Icon(Icons.favorite_border_rounded, color: p.dng, size: 32),
        title: const Text('Очистить избранное?'),
        content: const Text('Все сохранённые объявления будут убраны. Сохранённые поиски останутся.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Отмена')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: p.dng, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Очистить'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await S.i.clearFav();
    if (mounted) toast(context, 'Избранное очищено');
  }

  void _openSearch(Map<String, String> search) {
    S.i.pendingSearch = Map<String, String>.from(search);
    Navigator.pop(context);
    S.i.goTab(1);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: S.i,
      builder: (context, _) {
        final p = pal(context);
        final allFavs = S.i.ads.where((a) => S.i.isFav(a.id)).length;
        final ads = _filteredAds();
        final searches = List<Map<String, String>>.from(S.i.ss);
        return Scaffold(
          appBar: AppBar(
            title: const Text('Избранное'),
            actions: [
              if (S.i.logged && _section == 0 && allFavs > 0)
                IconButton(
                  tooltip: 'Очистить избранное',
                  onPressed: _clearFavorites,
                  icon: const Icon(Icons.delete_outline_rounded),
                ),
              const SizedBox(width: 4),
            ],
          ),
          body: !S.i.logged
              ? const NeedAuth(
                  icon: Icons.favorite_border_rounded,
                  title: 'Избранное',
                  text: 'Войдите, чтобы сохранять объявления и поиски. Всё сохранённое будет под рукой.')
              : SafeArea(
                  top: false,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 6, 16, 14),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('Сохраняйте нужное', style: TextStyle(fontSize: 14, color: p.mu)),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(color: p.bg2, borderRadius: BorderRadius.circular(16), border: Border.all(color: p.bd)),
                            child: Row(children: [
                              Expanded(child: _sectionButton(p, 0, 'Объявления', allFavs, Icons.favorite_border_rounded)),
                              const SizedBox(width: 4),
                              Expanded(child: _sectionButton(p, 1, 'Поиски', searches.length, Icons.manage_search_rounded)),
                            ]),
                          ),
                        ]),
                      ),
                      Expanded(child: _section == 0 ? _adsSection(p, ads, allFavs) : _searchSection(p, searches)),
                    ],
                  ),
                ),
        );
      },
    );
  }

  Widget _sectionButton(Pal p, int index, String label, int count, IconData icon) {
    final active = _section == index;
    return Material(
      color: active ? p.card : Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => setState(() => _section = index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 11),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: active ? p.bd : Colors.transparent),
            boxShadow: active ? [BoxShadow(color: Colors.black.withOpacity(.035), blurRadius: 8, offset: const Offset(0, 2))] : const [],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 18, color: active ? p.ac : p.mu),
            const SizedBox(width: 6),
            Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: active ? p.tx : p.mu))),
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(color: active ? p.ac.withOpacity(.11) : p.card, borderRadius: BorderRadius.circular(99)),
              child: Text('$count', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: active ? p.ac : p.mu)),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _adsSection(Pal p, List<Ad> ads, int total) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
        child: Column(children: [
          TextField(
            controller: _query,
            onChanged: (_) => setState(() {}),
            textInputAction: TextInputAction.search,
            decoration: deco(context, null, hint: 'Найти в избранном', prefix: Icon(Icons.search_rounded, color: p.mu), suffix: _query.text.isEmpty ? null : IconButton(tooltip: 'Очистить поиск', onPressed: () { _query.clear(); setState(() {}); }, icon: Icon(Icons.close_rounded, color: p.mu))),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Text('${ads.length} ${plural(ads.length, 'объявление', 'объявления', 'объявлений')}', style: TextStyle(color: p.mu, fontSize: 12, fontWeight: FontWeight.w700)),
            const Spacer(),
            PopupMenuButton<String>(
              initialValue: _sort,
              tooltip: 'Сортировка',
              onSelected: (v) => setState(() => _sort = v),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'new', child: Text('Сначала новые')),
                PopupMenuItem(value: 'old', child: Text('Сначала старые')),
              ],
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.swap_vert_rounded, size: 18, color: p.ac), const SizedBox(width: 4), Text(_sort == 'new' ? 'Сначала новые' : 'Сначала старые', style: TextStyle(color: p.ac, fontWeight: FontWeight.w700, fontSize: 12))]),
              ),
            ),
          ]),
        ]),
      ),
      Expanded(
        child: ads.isEmpty
            ? _emptyState(
                p,
                icon: total > 0 ? Icons.search_off_rounded : Icons.favorite_border_rounded,
                title: total > 0 ? 'Ничего не найдено' : 'Здесь пока пусто',
                text: total > 0
                    ? 'Попробуйте изменить запрос или очистить поиск.'
                    : 'Нажмите на сердечко у понравившегося объявления — оно появится здесь.',
                action: total == 0 ? 'Найти объявления' : null,
                onAction: total == 0 ? () { Navigator.pop(context); S.i.goTab(1); } : null,
              )
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 2, 16, 24),
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                itemCount: ads.length,
                itemBuilder: (c, i) => AdCard(
                  ad: ads[i],
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => AdPage(ad: ads[i]))),
                ),
              ),
      ),
    ]);
  }

  Widget _searchSection(Pal p, List<Map<String, String>> searches) {
    if (searches.isEmpty) {
      return _emptyState(
        p,
        icon: Icons.manage_search_rounded,
        title: 'Сохранённых поисков нет',
        text: 'Настройте поиск по словам, городу или категории и сохраните его — фильтры можно будет открыть в один нажим.',
        action: 'Настроить поиск',
        onAction: () { Navigator.pop(context); S.i.goTab(1); },
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      itemCount: searches.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (c, i) {
        final search = searches[i];
        final title = (search['q'] ?? '').trim().isNotEmpty
            ? search['q']!.trim()
            : (search['cat'] ?? '').trim().isNotEmpty
                ? search['cat']!.trim()
                : (search['city'] ?? '').trim().isNotEmpty
                    ? search['city']!.trim()
                    : (search['type'] ?? '').trim().isNotEmpty
                        ? search['type']!.trim()
                        : 'Сохранённый поиск';
        final summary = ssLabel(search);
        return Container(
          decoration: cardDeco(p, r: 18),
          padding: const EdgeInsets.all(14),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 42, height: 42, decoration: BoxDecoration(color: p.ac.withOpacity(.1), borderRadius: BorderRadius.circular(13)), child: Icon(Icons.search_rounded, color: p.ac)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 15, height: 1.25, fontWeight: FontWeight.w800, color: p.tx)),
              if (summary.isNotEmpty) ...[const SizedBox(height: 5), Text(summary, maxLines: 3, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.mu, fontSize: 12.5, height: 1.35))],
              const SizedBox(height: 11),
              Align(alignment: Alignment.centerLeft, child: GradBtn('Открыть поиск', icon: Icons.arrow_forward_rounded, onTap: () => _openSearch(search))),
            ])),
            const SizedBox(width: 6),
            IconButton(
              tooltip: 'Удалить поиск',
              visualDensity: VisualDensity.compact,
              onPressed: () async {
                final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(
                  icon: Icon(Icons.search_off_rounded, color: p.dng, size: 32),
                  title: const Text('Удалить поиск?'),
                  content: const Text('Сохранённые фильтры будут удалены из избранного.'),
                  actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Отмена')), FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Удалить'))],
                ));
                if (ok == true) {
                  S.i.ss.removeAt(i);
                  await S.i.saveSS();
                  if (mounted) toast(context, 'Поиск удалён');
                }
              },
              icon: Icon(Icons.close_rounded, color: p.mu, size: 20),
            ),
          ]),
        );
      },
    );
  }

  Widget _emptyState(Pal p, {required IconData icon, required String title, required String text, String? action, VoidCallback? onAction}) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(28, 22, 28, 32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 68, height: 68, decoration: BoxDecoration(color: p.bg2, borderRadius: BorderRadius.circular(22), border: Border.all(color: p.bd)), child: Icon(icon, size: 31, color: p.ac)),
          const SizedBox(height: 16),
          Text(title, textAlign: TextAlign.center, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: p.tx)),
          const SizedBox(height: 7),
          Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 14, height: 1.45, color: p.mu)),
          if (action != null && onAction != null) ...[const SizedBox(height: 18), SizedBox(width: 230, child: GradBtn(action, onTap: onAction, icon: Icons.search_rounded))],
        ]),
      ),
    );
  }
}
