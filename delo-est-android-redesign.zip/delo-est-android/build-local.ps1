param(
  [ValidateRange(1, 2100000000)]
  [int]$BuildNumber = 2026101601
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw 'Flutter не найден. Установите Flutter SDK, добавьте flutter\bin в PATH и перезапустите терминал.'
}
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
  throw 'Python не найден. Установите Python 3 и добавьте его в PATH.'
}

Write-Host '1/6 Создаю локальный Android-каркас Flutter...'
if (Test-Path 'shell') { Remove-Item 'shell' -Recurse -Force }
flutter create --org ru.deloest --project-name delo_est --platforms android --no-pub shell
if ($LASTEXITCODE -ne 0) { throw 'flutter create завершился с ошибкой.' }

Write-Host '2/6 Копирую исходники и ресурсы...'
Remove-Item 'shell/lib' -Recurse -Force -ErrorAction SilentlyContinue
New-Item 'shell/lib' -ItemType Directory -Force | Out-Null
New-Item 'shell/assets' -ItemType Directory -Force | Out-Null
Copy-Item '*.dart' 'shell/lib/' -Force
Copy-Item 'pubspec.yaml' 'shell/' -Force
foreach ($name in @('icon.png', 'icon_fg.png', 'icon_orange.png', 'icon_purple.png')) {
  if (-not (Test-Path $name)) { throw "Не найден файл $name" }
  Copy-Item $name "shell/assets/$name" -Force
}

Write-Host '3/6 Устанавливаю зависимости и создаю иконки...'
Push-Location 'shell'
try {
  flutter pub get
  if ($LASTEXITCODE -ne 0) { throw 'flutter pub get завершился с ошибкой.' }
  dart run flutter_launcher_icons
  if ($LASTEXITCODE -ne 0) { throw 'Генерация иконок завершилась с ошибкой.' }
  Write-Host '4/6 Настраиваю Android-манифест и переключение иконки...'
  python ..\configure_android.py
  if ($LASTEXITCODE -ne 0) { throw 'Настройка Android завершилась с ошибкой.' }
} finally {
  Pop-Location
}

Write-Host '5/6 Подготавливаю ключ подписи приложения...'
$AndroidDir = Join-Path $env:USERPROFILE '.android'
New-Item $AndroidDir -ItemType Directory -Force | Out-Null
$KeyTarget = Join-Path $AndroidDir 'debug.keystore'
if (Test-Path $KeyTarget) {
  $backup = Join-Path $AndroidDir ('debug.keystore.backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
  Copy-Item $KeyTarget $backup -Force
  Write-Host "Существующий ключ сохранён: $backup"
}
Copy-Item 'debug.keystore' $KeyTarget -Force

Write-Host '6/6 Собираю APK...'
Push-Location 'shell'
try {
  flutter build apk --release --build-name=1.0.0 --build-number=$BuildNumber
  if ($LASTEXITCODE -ne 0) { throw 'Сборка APK завершилась с ошибкой.' }
} finally {
  Pop-Location
}
$Apk = Join-Path $Root 'shell\build\app\outputs\flutter-apk\app-release.apk'
if (-not (Test-Path $Apk)) { throw "APK не найден по ожидаемому пути: $Apk" }
Copy-Item $Apk (Join-Path $Root 'DeloEst.apk') -Force
Write-Host ''
Write-Host 'Готово: DeloEst.apk' -ForegroundColor Green
Write-Host "Путь: $(Join-Path $Root 'DeloEst.apk')"
